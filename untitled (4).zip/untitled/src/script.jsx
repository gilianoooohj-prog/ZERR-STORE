import React from "react";
import ReactDOM from "react-dom/client";

function App() {
  return (
    <main>
      <header>
        <div class="icon">⚛️</div> Site Powered by React
      </header>
    </main>
  );
}

const root = ReactDOM.createRoot(document.getElementById("app"));

root.render(<App />);
let buyerCount = 127;

const buyers = ["Acursio", "Rizky", "Fahmi", "Dimas", "Rafa", "Alvin"];

function showPurchaseNotification() {
  const notification = document.getElementById("purchaseNotification");
  const buyerName = document.getElementById("buyerName");

  const randomBuyer = buyers[Math.floor(Math.random() * buyers.length)];

  buyerName.textContent = randomBuyer;

  notification.classList.add("show");

  setTimeout(() => {
    notification.classList.remove("show");
  }, 4000);
}

function buyProduct() {
  buyerCount++;

  document.getElementById("buyerCount").textContent = buyerCount;

  showPurchaseNotification();
}

// Demo activity
setTimeout(showPurchaseNotification, 3000);

setInterval(() => {
  showPurchaseNotification();
}, 15000);
